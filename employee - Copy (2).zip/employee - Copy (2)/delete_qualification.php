<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'not_logged_in']);
    exit;
}

if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    echo json_encode(['success' => false, 'error' => 'invalid_id']);
    exit;
}

 $user_id = $_SESSION['user_id'];
 $qual_id = (int)$_POST['id'];

// First, get the employee_id from the qualification
 $stmt = $pdo->prepare("SELECT employee_id FROM employee_qualifications WHERE id = ?");
 $stmt->execute([$qual_id]);
 $qual = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$qual) {
    echo json_encode(['success' => false, 'error' => 'qualification_not_found']);
    exit;
}

// Verify the employee belongs to this user (check both draft and submitted)
 $stmt = $pdo->prepare("SELECT id FROM employees WHERE id = ? AND user_id = ?");
 $stmt->execute([$qual['employee_id'], $user_id]);
if (!$stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'not_allowed']);
    exit;
}

// Delete the qualification
 $stmt = $pdo->prepare("DELETE FROM employee_qualifications WHERE id = ?");
 $ok = $stmt->execute([$qual_id]);

if ($ok) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'delete_failed']);
}
?>