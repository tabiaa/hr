<?php
// generate_pdf.php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: form.php');
    exit;
}

 $submitted_id = intval($_GET['id']);
 $user_id = $_SESSION['user_id'];

// Verify the form belongs to the current user
 $stmt = $pdo->prepare("SELECT id FROM submitted_employees WHERE id = ? AND user_id = ?");
 $stmt->execute([$submitted_id, $user_id]);
if (!$stmt->fetch()) {
    header('Location: form.php');
    exit;
}

// Get employee data
 $stmt = $pdo->prepare("SELECT * FROM submitted_employees WHERE id = ?");
 $stmt->execute([$submitted_id]);
 $employee = $stmt->fetch(PDO::FETCH_ASSOC);

// Get qualifications
 $stmt = $pdo->prepare("SELECT * FROM s_employee_qualifications WHERE employee_id = ?");
 $stmt->execute([$submitted_id]);
 $qualifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get relatives
 $stmt = $pdo->prepare("SELECT * FROM submitted_relatives WHERE employee_id = ?");
 $stmt->execute([$submitted_id]);
 $relatives = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Employee Form - <?= htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            background: #f4f6f9;
        }
        .print-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header { 
            text-align: center; 
            margin-bottom: 30px; 
            border-bottom: 3px solid #003366;
            padding-bottom: 20px;
        }
        .logo { 
            height: 80px; 
            margin-bottom: 10px; 
        }
        h1 { 
            color: #003366; 
            margin: 0;
            font-size: 28px;
            font-weight: bold;
        }
        h2 { 
            color: #003366; 
            border-bottom: 2px solid #003366; 
            padding-bottom: 5px; 
            margin-top: 30px;
            font-size: 20px;
        }
        .info-section {
            margin-bottom: 25px;
        }
        .info-row { 
            margin-bottom: 10px; 
            display: flex;
        }
        .info-label { 
            font-weight: bold; 
            width: 250px; 
            flex-shrink: 0;
        }
        .info-value {
            flex-grow: 1;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 20px; 
        }
        th, td { 
            border: 1px solid #ddd; 
            padding: 10px; 
            text-align: left; 
        }
        th { 
            background-color: #f8f9fa; 
            font-weight: bold;
        }
        .no-data { 
            color: #666; 
            font-style: italic; 
        }
        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        }
        @media print {
            .no-print { 
                display: none !important; 
            }
            body { 
                margin: 0; 
                background: white;
            }
            .print-container {
                box-shadow: none;
                border-radius: 0;
                padding: 15px;
            }
            .info-row {
                page-break-inside: avoid;
            }
            table {
                page-break-inside: auto;
            }
            tr {
                page-break-inside: avoid;
                page-break-after: auto;
            }
        }
    </style>
</head>
<body>
    <button class="btn btn-primary print-btn no-print" onclick="window.print()">
        <i class="fas fa-print"></i> Print / Save as PDF
    </button>

    <div class="print-container">
        <div class="header">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaarmtvsidpiXn07q3BVfrz7Qsui3AdF6-Gw&s" alt="SSGC Logo" class="logo">
            <h1>SUI SOUTHERN GAS COMPANY LIMITED</h1>
            <h3>Employee Form</h3>
        </div>

        <div class="info-section">
            <h2>Personal Information</h2>
            <div class="info-row">
                <span class="info-label">First Name:</span>
                <span class="info-value"><?= htmlspecialchars($employee['first_name'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Last Name:</span>
                <span class="info-value"><?= htmlspecialchars($employee['last_name'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">CNIC:</span>
                <span class="info-value"><?= htmlspecialchars($employee['cnic'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Marital Status:</span>
                <span class="info-value"><?= htmlspecialchars($employee['marital_status'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Permanent Address:</span>
                <span class="info-value"><?= htmlspecialchars($employee['permanent_address'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Current Address:</span>
                <span class="info-value"><?= htmlspecialchars($employee['current_address'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Contact Number:</span>
                <span class="info-value"><?= htmlspecialchars($employee['contact_number'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Next of Kin Name:</span>
                <span class="info-value"><?= htmlspecialchars($employee['next_of_kin_name'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Next of Kin CNIC:</span>
                <span class="info-value"><?= htmlspecialchars($employee['next_of_kin_cnic'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Nationality:</span>
                <span class="info-value"><?= htmlspecialchars($employee['nationality'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Blood Group:</span>
                <span class="info-value"><?= htmlspecialchars($employee['blood_group'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Emergency Contact Name:</span>
                <span class="info-value"><?= htmlspecialchars($employee['emergency_contact_name'] ?? '') ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Emergency Contact Number:</span>
                <span class="info-value"><?= htmlspecialchars($employee['emergency_contact_number'] ?? '') ?></span>
            </div>
        </div>

        <div class="info-section">
            <h2>Qualifications / Certifications</h2>
            <?php if (count($qualifications) > 0): ?>
                <table>
                    <tr>
                        <th style="width: 70%;">Qualification Name</th>
                        <th style="width: 30%;">Certificate</th>
                    </tr>
                    <?php foreach ($qualifications as $q): ?>
                    <tr>
                        <td><?= htmlspecialchars($q['qualification_name']) ?></td>
                        <td><?= $q['certificate_file'] ? 'Attached' : 'Not Attached' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            <?php else: ?>
                <p class="no-data">No qualifications added.</p>
            <?php endif; ?>
        </div>

        <div class="info-section">
            <h2>Relatives / Dependents</h2>
            <?php if (count($relatives) > 0): ?>
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Relation</th>
                        <th>CNIC</th>
                        <th>Date of Birth</th>
                        <th>Medical Elsewhere</th>
                    </tr>
                    <?php foreach ($relatives as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['first_name'] . ' ' . $r['last_name']) ?></td>
                        <td><?= htmlspecialchars($r['relation_type']) ?></td>
                        <td><?= htmlspecialchars($r['cnic']) ?></td>
                        <td><?= htmlspecialchars($r['date_of_birth']) ?></td>
                        <td><?= $r['availing_medical_elsewhere'] ? 'Yes' : 'No' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            <?php else: ?>
                <p class="no-data">No relatives added.</p>
            <?php endif; ?>
        </div>

        <div class="no-print" style="margin-top: 30px; text-align: center; color: #666;">
            <p>Generated on: <?= date('d-M-Y H:i:s') ?></p>
            <p class="mt-2">
                <small>To save as PDF: Click the Print button above, then select "Save as PDF" as the destination printer</small>
            </p>
        </div>
    </div>

    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        // Auto-trigger print dialog when page loads
        window.onload = function() {
            setTimeout(function() {
                // Uncomment the next line if you want to auto-open print dialog
                // window.print();
            }, 500);
        }
    </script>
</body>
</html>