<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'not_logged_in']);
    exit;
}

if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    echo json_encode(['success' => false, 'error' => 'invalid_id']);
    exit;
}

$user_id = $_SESSION['user_id'];
$rel_id = (int)$_POST['id'];

$stmt = $pdo->prepare("
    SELECT r.id 
    FROM relatives r
    JOIN employees e ON r.employee_id = e.id
    WHERE r.id = ? AND e.user_id = ? AND e.draft = 1
");
$stmt->execute([$rel_id, $user_id]);
if (!$stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'not_allowed']);
    exit;
}


$stmt = $pdo->prepare("DELETE FROM relatives WHERE id = ?");
$ok = $stmt->execute([$rel_id]);

echo json_encode(['success' => $ok]);
