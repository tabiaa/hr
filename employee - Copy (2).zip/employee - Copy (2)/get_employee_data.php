<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db.php';

header('Content-Type: application/json');

try {
    if (isset($_GET['employee_no']) && !empty($_GET['employee_no'])) {
        $employee_no = trim($_GET['employee_no']);
        
        // Get employee data
        $stmt = $pdo->prepare("SELECT * FROM hr_employee WHERE employee_no = ? LIMIT 1");
        $stmt->execute([$employee_no]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get relations data
        $stmt = $pdo->prepare("SELECT * FROM hr_employee_relations WHERE employee_no = ?");
        $stmt->execute([$employee_no]);
        $relations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($employee) {
            echo json_encode([
                'success' => true,
                'data' => $employee,
                'relations' => $relations
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => "No employee found with employee number: $employee_no"
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Employee number is required'
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>