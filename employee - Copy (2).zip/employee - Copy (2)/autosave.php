<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => 0, 'error' => 'Not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];

// gather fields allowed for autosave (only text/select/textarea values). Files are not handled here.
$allowed = [
    'first_name','last_name','cnic','marital_status','permanent_address','current_address',
    'contact_number','next_of_kin_name','next_of_kin_cnic_raw','nationality','blood_group',
    'emergency_contact_name','emergency_contact_number'
];

$data = [];
foreach ($allowed as $k) {
    if (isset($_POST[$k])) {
        $name = $k;
        // map next_of_kin_cnic_raw to next_of_kin_cnic column if present
        if ($k === 'next_of_kin_cnic_raw') $name = 'next_of_kin_cnic';
        $data[$name] = trim($_POST[$k]);
    }
}

// Ensure CNIC stored as digits only
if (isset($data['cnic'])) {
    $data['cnic'] = preg_replace('/\D/','',$data['cnic']);
}
if (isset($data['next_of_kin_cnic'])) {
    $data['next_of_kin_cnic'] = preg_replace('/\D/','',$data['next_of_kin_cnic']);
}

// ensure nationality default
if (empty($data['nationality'])) $data['nationality'] = 'Pakistani';

// draft mode
$data['draft'] = 1;
$data['user_id'] = $user_id;

try {
    // if id provided and exists, update
    if (!empty($_POST['id'])) {
        $id = intval($_POST['id']);
        // verify that this id belongs to this user and is a draft
        $stmt = $pdo->prepare("SELECT id FROM employees WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $user_id]);
        if ($stmt->fetch()) {
            $set = [];
            foreach ($data as $k => $v) $set[] = "$k = :$k";
            $sql = "UPDATE employees SET " . implode(',', $set) . " WHERE id = :id";
            $data['id'] = $id;
            $stmt = $pdo->prepare($sql);
            $stmt->execute($data);
            echo json_encode(['success'=>1,'id'=>$id]);
            exit;
        }
    }

    // else insert a new draft row
    $keys = implode(',', array_keys($data));
    $vals = ':' . implode(',:', array_keys($data));
    $stmt = $pdo->prepare("INSERT INTO employees ($keys) VALUES ($vals)");
    $stmt->execute($data);
    $newId = $pdo->lastInsertId();
    echo json_encode(['success'=>1,'id'=>$newId]);
    exit;

} catch (PDOException $e) {
    echo json_encode(['success'=>0,'error'=>$e->getMessage()]);
    exit;
}
