<?php
session_start();
include('db.php'); 

$ldap_host = "ldap://suigas.pk";
$ldap_port = 389;
$ldap_domain = "SUIGAS";
$ldap_dn = "DC=suigas,DC=pk";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login_id = trim($_POST['login_id']);
    $password = $_POST['password'];

    if (empty($login_id) || empty($password)) {
        $error = "Please enter both username and password.";
    } else {
        $ldap_conn = ldap_connect($ldap_host, $ldap_port);
        if (!$ldap_conn) {
            $error = "Could not connect to LDAP server.";
        } else {
            ldap_set_option($ldap_conn, LDAP_OPT_PROTOCOL_VERSION, 3);
            ldap_set_option($ldap_conn, LDAP_OPT_REFERRALS, 0);

            $ldap_user = "$ldap_domain\\$login_id";

            if (@ldap_bind($ldap_conn, $ldap_user, $password)) {

                $filter = "(sAMAccountName=$login_id)";
                $result = ldap_search($ldap_conn, $ldap_dn, $filter);
                $entries = ldap_get_entries($ldap_conn, $result);

                $full_name = $entries[0]['cn'][0] ?? $login_id;
                $email = $entries[0]['mail'][0] ?? null;

                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
                $stmt->execute([$login_id]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$user) {
                    $insert = $pdo->prepare("INSERT INTO users (username, full_name, email, status) VALUES (?, ?, ?, 'active')");
                    $insert->execute([$login_id, $full_name, $email]);
                    $user_id = $pdo->lastInsertId();
                } else {
                    $user_id = $user['id'];
                }

                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $full_name;

                ldap_unbind($ldap_conn);
                header('Location: form.php');
                exit;
            } else {
                $error = "Invalid Active Directory credentials.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Employee Login | SSGC</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<style>
body {
    background: linear-gradient(135deg, #e6f0ff, #ffffff);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Segoe UI', Arial, sans-serif;
}
.login-card {
    width: 100%;
    max-width: 450px;
    background: rgba(255,255,255,0.97);
    border-radius: 15px;
    box-shadow: 0 6px 25px rgba(0,0,0,0.1);
    padding: 40px 30px;
}
.logo-section {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    margin-bottom: 25px;
}
.logo-section img {
    height: 75px;
}
.logo-section h3 {
    font-size: 22px;
    font-weight: 700;
    color: #003366;
}
.login-card h5 {
    text-align: center;
    color: #004080;
    font-weight: 600;
    margin-bottom: 25px;
}
.form-control {
    border-radius: 10px;
    padding: 12px;
    font-size: 15px;
}
.btn-primary {
    background-color: #004080;
    border: none;
    border-radius: 10px;
    font-weight: 600;
    padding: 12px;
    transition: background 0.3s ease;
}
.btn-primary:hover {
    background-color: #0066cc;
}
.alert {
    border-radius: 10px;
    font-size: 14px;
}
footer {
    text-align: center;
    font-size: 13px;
    color: #777;
    margin-top: 25px;
}
</style>
</head>
<body>
<div class="login-card">
    <div class="logo-section">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaarmtvsidpiXn07q3BVfrz7Qsui3AdF6-Gw&s" alt="SSGC Logo">
        <h3>SUI SOUTHERN GAS COMPANY LIMITED</h3>
    </div>

    <?php if(isset($error)): ?>
        <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <h5>Employee Login</h5>
    <form method="POST" novalidate>
        <div class="mb-3">
            <label class="form-label fw-semibold">Username or Email</label>
            <input type="text" name="login_id" class="form-control" placeholder="Enter your username or email" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-semibold">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
        </div>
        <button class="btn btn-primary w-100" type="submit">Login</button>
    </form>

    <footer>
        © <?= date('Y'); ?> Sui Southern Gas Company Limited
    </footer>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
