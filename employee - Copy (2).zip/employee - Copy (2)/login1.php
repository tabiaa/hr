<?php
session_start();
include('db.php'); 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login_id = trim($_POST['login_id']);
    $password = $_POST['password'];

    if (empty($login_id) || empty($password)) {
        $error = "Please enter both username/email and password.";
    } else {
        // Check user by username OR email
        $stmt = $pdo->prepare("SELECT id, username, full_name, password_hash, status FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$login_id, $login_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            if ($user['status'] !== 'active') {
                $error = "Your account is inactive. Please contact the administrator.";
            } elseif ($password === $user['password_hash']) {
                // ✅ Successful login
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'] ?? $user['username'];

                header('Location: form.php');
                exit;
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "No user found with that username or email.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Employee Login | SSGC</title>
 <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    body {
      background: linear-gradient(135deg, #e6f0ff, #ffffff);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Segoe UI', Arial, sans-serif;
    }
    .login-card {
      width: 100%;
      max-width: 430px;
      background: rgba(255, 255, 255, 0.95);
      border-radius: 15px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
      padding: 35px 30px;
      backdrop-filter: blur(8px);
    }
    .logo-section {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 15px;
      margin-bottom: 15px;
    }
    .logo-section img {
      height: 75px;
      width: auto;
    }
    .logo-section h3 {
      font-size: 22px;
      font-weight: 700;
      color: #003366;
      margin: 0;
      text-align: center;
    }
    .login-card h5 {
      text-align: center;
      color: #004080;
      font-weight: 600;
      margin-bottom: 25px;
    }
    .form-control {
      border-radius: 10px;
      padding: 12px;
      font-size: 15px;
    }
    .btn-primary {
      background-color: #004080;
      border: none;
      border-radius: 10px;
      font-weight: 600;
      padding: 12px;
      transition: background 0.3s ease;
    }
    .btn-primary:hover {
      background-color: #0066cc;
    }
    .alert {
      border-radius: 10px;
      font-size: 14px;
    }
    footer {
      text-align: center;
      font-size: 13px;
      color: #777;
      margin-top: 25px;
    }
  </style>
</head>
<body>
  <div class="login-card">
    <div class="logo-section">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaarmtvsidpiXn07q3BVfrz7Qsui3AdF6-Gw&s" alt="SSGC Logo">
      <h3>SUI SOUTHERN GAS COMPANY LIMITED</h3>
    </div>

    <?php if(isset($error)): ?>
      <div class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
      <div class="mb-3">
        <label class="form-label fw-semibold">Username or Email</label>
        <input type="text" name="login_id" class="form-control text-uppercase" placeholder="ENTER YOUR USERNAME OR EMAIL" required>
      </div>
      <div class="mb-3">
        <label class="form-label fw-semibold">Password</label>
        <input type="password" name="password" class="form-control" placeholder="ENTER YOUR PASSWORD" required>
      </div>
      <button class="btn btn-primary w-100" type="submit">LOGIN</button>
    </form>

    <footer>
      © <?= date('Y'); ?> Sui Southern Gas Company Limited
    </footer>
  </div>
</body>
</html>
