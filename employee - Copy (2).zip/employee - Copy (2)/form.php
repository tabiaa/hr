<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

 $user_id = $_SESSION['user_id'];
 $employee = [];
 $qualifications = [];
 $relatives = [];
 $submitted_view = false;

 $stmt = $pdo->prepare("SELECT * FROM employees WHERE user_id = ? AND draft = 1 LIMIT 1");
 $stmt->execute([$user_id]);
 $employee = $stmt->fetch(PDO::FETCH_ASSOC);

if (isset($_GET['id']) && isset($_GET['status']) && $_GET['status'] === 'submitted') {
    $submitted_view = true;
    $submitted_id = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT * FROM submitted_employees WHERE id = ? LIMIT 1");
    $stmt->execute([$submitted_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM s_employee_qualifications WHERE employee_id = ?");
    $stmt->execute([$submitted_id]);
    $qualifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM submitted_relatives WHERE employee_id = ?");
    $stmt->execute([$submitted_id]);
    $relatives = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    if ($employee) {
        $employee_id = $employee['id'];
        $stmt = $pdo->prepare("SELECT * FROM employee_qualifications WHERE employee_id=?");
        $stmt->execute([$employee_id]);
        $qualifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("SELECT * FROM relatives WHERE employee_id=?");
        $stmt->execute([$employee_id]);
        $relatives = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!doctype html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <meta charset="utf-8">
    <title>Employee Form</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/all.min.css">
    <style>
        body { 
            background-color: #f4f6f9; 
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
        }
        .main-container {
            display: flex;
            margin-top: 10px;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #003366, #0055a4);
            color: white;
            padding: 15px 0;
            border-radius: 0 10px 10px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: sticky;
            top: 10px;
            height: fit-content;
            overflow-y: auto;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            border-radius: 0;
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background-color: rgba(255,255,255,0.1);
            color: white;
        }
        .sidebar .nav-link i {
            margin-right: 10px;
        }
        .content-area {
            flex: 1;
            padding: 15px;
        }
        .section {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            background: #fff;
            display: none;
        }
        .section.active {
            display: block;
        }
        .header-section {
            background: linear-gradient(90deg, #ffffff, #f3f7ff);
            padding: 15px 20px;
            border-bottom: 3px solid #003366;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            border-radius: 10px;
        }
        .relative-item { 
            padding:10px; 
            border:1px solid #e6e6e6; 
            border-radius:6px; 
            margin-bottom:8px; 
            background:#fff; 
            display:flex; 
            justify-content:space-between; 
            align-items:center; 
        }
        .file-preview img { 
            max-width:150px; 
            border-radius:6px; 
            margin-top:6px; 
            border:1px solid #ccc; 
        }
        .required { color:#d00; }
        .small-note { font-size:0.9rem; color:#666; }
        .remove-btn { cursor:pointer; color:red; font-size:20px; font-weight:bold; }
        #relatives-table { margin-top: 15px; }
        #relatives-table .table-responsive { border: 1px solid #dee2e6; border-radius: 8px; }
        #relatives-table th { background-color: #f8f9fa; }
        #relative-form-fields { border-bottom: 2px solid #e9ecef; padding-bottom: 15px; margin-bottom: 15px; }
        .submitted-form-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 12px;
            background: white;
            transition: all 0.3s;
        }
        .submitted-form-card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        .pdf-viewer {
            border: 1px solid #ddd;
            border-radius: 8px;
            height: 600px;
            overflow: auto;
            background: white;
            padding: 15px;
        }
        .form-actions {
            position: sticky;
            bottom: 0;
            background: white;
            padding: 10px 15px;
            border-top: 1px solid #ddd;
            text-align: right;
            z-index: 10;
        }
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        .step {
            flex: 1;
            text-align: center;
            position: relative;
        }
        .step::before {
            content: '';
            position: absolute;
            top: 15px;
            left: 50%;
            right: -50%;
            height: 2px;
            background: #ddd;
            z-index: -1;
        }
        .step:last-child::before {
            display: none;
        }
        .step.active::before {
            background: #003366;
        }
        .step-circle {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #ddd;
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 5px;
        }
        .step.active .step-circle {
            background: #003366;
        }
        .step.completed .step-circle {
            background: #28a745;
        }
        .print-only {
            display: none;
        }
        @media print {
            .no-print {
                display: none !important;
            }
            .print-only {
                display: block !important;
            }
            .section {
                display: block !important;
                page-break-after: always;
            }
        }
        /* Additional fixes for excessive space */
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }
        .d-flex {
            margin-bottom: 0;
        }
        h1, h2, h3, h4, h5 {
            margin-top: 0.5rem;
            margin-bottom: 0.8rem;
        }
        /* Custom styles for readonly fields */
        .readonly-field {
            background-color: #f8f9fa;
            border: 1px solid #ced4da;
        }
        .relation-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
            overflow: hidden;
        }
        .relation-card .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #ddd;
            padding: 10px 15px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="header-section d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <img 
                    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaarmtvsidpiXn07q3BVfrz7Qsui3AdF6-Gw&s" 
                    alt="SSGC Logo" 
                    style="height: 80px; width: auto; margin-right: 20px;"
                >
                <h1 style="
                    margin: 0;
                    font-size: 30px;
                    font-weight: 700;
                    color: #003366;
                    font-family: 'Segoe UI', Arial, sans-serif;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                ">
                    SUI SOUTHERN GAS COMPANY LIMITED
                </h1>
            </div>
            <a class="btn btn-outline-secondary no-print" href="logout.php">Logout</a>
        </div>

        <?php if ($submitted_view): ?>
            <div class="alert alert-success no-print">This form has been submitted and is read-only.</div>
            
            <div class="main-container">
                <div class="sidebar no-print">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#" data-section="personal">
                                <i class="fas fa-user"></i> Personal Information
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="qualifications">
                                <i class="fas fa-graduation-cap"></i> Qualifications
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="relatives">
                                <i class="fas fa-users"></i> Relatives
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" id="download-pdf">
                                <i class="fas fa-file-pdf"></i> Download PDF
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="form.php">
                                <i class="fas fa-arrow-left"></i> Back to Forms
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="content-area">
                    <div class="step-indicator no-print">
                        <div class="step active" data-step="1">
                            <div class="step-circle">1</div>
                            <div>Personal</div>
                        </div>
                        <div class="step" data-step="2">
                            <div class="step-circle">2</div>
                            <div>Qualifications</div>
                        </div>
                        <div class="step" data-step="3">
                            <div class="step-circle">3</div>
                            <div>Relatives</div>
                        </div>
                    </div>
                    
                    <!-- Personal Information Section -->
                    <div id="personal-section" class="section active">
                        <h4 class="text-secondary border-bottom pb-2 mb-3">Personal Information</h4>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label>First Name</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['first_name'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Last Name</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['last_name'] ?? '') ?>">
                            </div>
                            
<div class="col-md-6">
    <label>Employee Number</label>
    <input type="text" name="employee_no" id="employee_no" class="form-control" value="<?= htmlspecialchars($employee['employee_no'] ?? '') ?>">
    <div class="small-note">Enter employee number to auto-fill details</div>
</div>
                            <div class="col-md-6">
                                <label>CNIC</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['cnic'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Marital Status</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['marital_status'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Permanent Address</label>
                                <textarea readonly class="form-control"><?= htmlspecialchars($employee['permanent_address'] ?? '') ?></textarea>
                            </div>
                            <div class="col-md-6">
                                <label>Current Address</label>
                                <textarea readonly class="form-control"><?= htmlspecialchars($employee['current_address'] ?? '') ?></textarea>
                            </div>
                            <div class="col-md-6">
                                <label>Contact Number</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['contact_number'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Next of Kin Name</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['next_of_kin_name'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Next of Kin CNIC</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['next_of_kin_cnic'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Nationality</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['nationality'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Blood Group</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['blood_group'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Emergency Contact Name</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['emergency_contact_name'] ?? '') ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Emergency Contact Number</label>
                                <input type="text" readonly class="form-control" value="<?= htmlspecialchars($employee['emergency_contact_number'] ?? '') ?>">
                            </div>
                        </div>
                        
                        <h5 class="mt-4 mb-3">Uploaded Documents</h5>
                        <div class="row">
                            <?php
                            $files = ['cnic_front'=>'CNIC Front','cnic_back'=>'CNIC Back','passport_photo'=>'Passport Photo','frc'=>'Family Registration Certificate (FRC)'];
                            foreach($files as $f => $label):
                            ?>
                            <div class="col-md-6 mb-3">
                                <label class="fw-semibold"><?= htmlspecialchars($label) ?></label>
                                <?php if(!empty($employee[$f])) :
                                    $fileExt = strtolower(pathinfo($employee[$f], PATHINFO_EXTENSION));
                                    if(in_array($fileExt, ['jpg','jpeg','png'])): ?>
                                        <div class="file-preview"><img src="<?= htmlspecialchars($employee[$f]) ?>" alt="<?= $label ?>"></div>
                                    <?php else: ?>
                                        <div><a href="<?= htmlspecialchars($employee[$f]) ?>" target="_blank" class="btn btn-sm btn-outline-primary">View File</a></div>
                                    <?php endif;
                                endif; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Qualifications Section -->
                    <div id="qualifications-section" class="section">
                        <h4 class="text-secondary border-bottom pb-2 mb-3">Qualifications / Certifications</h4>
                        <?php if (count($qualifications) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Qualification Name</th>
                                            <th>Certificate</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($qualifications as $q): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($q['qualification_name']) ?></td>
                                            <td>
                                                <?php if(!empty($q['certificate_file'])): ?>
                                                    <a href="<?= htmlspecialchars($q['certificate_file']) ?>" target="_blank" class="btn btn-sm btn-outline-primary">View Certificate</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p>No qualifications added.</p>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Relatives Section -->
                    <div id="relatives-section" class="section">
                        <h4 class="text-secondary border-bottom pb-2 mb-3">Relatives / Dependents</h4>
                        <?php if (count($relatives) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Relation</th>
                                            <th>ID Type</th>
                                            <th>ID Number</th>
                                            <th>Date of Birth</th>
                                            <th>Blood Group</th>
                                            <th>Medical Elsewhere</th>
                                            <th>Documents</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($relatives as $r): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($r['first_name'] . ' ' . $r['last_name']) ?></td>
                                            <td><?= htmlspecialchars($r['relation_type']) ?></td>
                                            <td><?= htmlspecialchars($r['id_type'] ?? 'CNIC') ?></td>
                                            <td><?= htmlspecialchars($r['cnic']) ?></td>
                                            <td><?= htmlspecialchars($r['date_of_birth']) ?></td>
                                            <td><?= htmlspecialchars($r['blood_group'] ?? '') ?></td>
                                            <td><?= $r['availing_medical_elsewhere'] ? 'Yes' : 'No' ?></td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    <?php if (!empty($r['cnic_front'])): ?><a href="<?= htmlspecialchars($r['cnic_front']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">Front</a><?php endif; ?>
                                                    <?php if (!empty($r['cnic_back'])): ?><a href="<?= htmlspecialchars($r['cnic_back']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">Back</a><?php endif; ?>
                                                    <?php if (!empty($r['passport_photo'])): ?><a href="<?= htmlspecialchars($r['passport_photo']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">Photo</a><?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p>No relatives added.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Submitted Forms List -->
            <div class="main-container">
                <div class="sidebar no-print">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#" data-section="forms">
                                <i class="fas fa-list"></i> Submitted Forms
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="new">
                                <i class="fas fa-plus"></i> New Form
                            </a>
                        </li>
                    </ul>
                </div>
                

                <div class="content-area">
                    <!-- Submitted Forms Section -->
                    <div id="forms-section" class="section active">
                        <h4 class="text-secondary border-bottom pb-2 mb-3">Your Submitted Forms</h4>
                        <?php
                        $stmt = $pdo->prepare("SELECT id, first_name, last_name, cnic, created_at FROM submitted_employees WHERE user_id = ? ORDER BY created_at DESC");
                        $stmt->execute([$user_id]);
                        $submitted_forms = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        
                        <?php if (count($submitted_forms) > 0): ?>
                            <div class="row">
                                <?php foreach($submitted_forms as $sf): ?>
                                <div class="col-md-6 mb-3">
                                    <div class="submitted-form-card">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h5><?= htmlspecialchars($sf['first_name'] . ' ' . $sf['last_name']) ?></h5>
                                                <p class="mb-1"><strong>CNIC:</strong> <?= htmlspecialchars($sf['cnic']) ?></p>
                                                <p class="mb-0"><strong>Submitted:</strong> <?= htmlspecialchars(date('d-M-Y H:i', strtotime($sf['created_at']))) ?></p>
                                            </div>
                                            <div>
                                                <a href="form.php?id=<?= (int)$sf['id'] ?>&status=submitted" class="btn btn-sm btn-outline-primary me-2">View</a>
                                                <a href="generate_pdf.php?id=<?= (int)$sf['id'] ?>" class="btn btn-sm btn-outline-danger" target="_blank">PDF</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- New Form Section -->
                    <div id="new-section" class="section">
                        <h4 class="text-secondary border-bottom pb-2 mb-3">Create New Form</h4>
                        <div class="text-center py-5">
                            <p>You can create a new employee form by clicking the button below.</p>
                            <a href="form.php?new=1" class="btn btn-primary">Create New Form</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Form Editor (when creating/editing a form) -->
            <?php if (isset($_GET['new']) || $employee): ?>
            <div class="main-container">
                <div class="sidebar no-print">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#" data-section="personal">
                                <i class="fas fa-user"></i> Personal Information
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="qualifications">
                                <i class="fas fa-graduation-cap"></i> Qualifications
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" data-section="relatives">
                                <i class="fas fa-users"></i> Relatives
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="form.php">
                                <i class="fas fa-arrow-left"></i> Back to Forms
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="content-area">
                    <div class="step-indicator no-print">
                        <div class="step active" data-step="1">
                            <div class="step-circle">1</div>
                            <div>Personal</div>
                        </div>
                        <div class="step" data-step="2">
                            <div class="step-circle">2</div>
                            <div>Qualifications</div>
                        </div>
                        <div class="step" data-step="3">
                            <div class="step-circle">3</div>
                            <div>Relatives</div>
                        </div>
                    </div>
                    
                    <form id="employeeForm" action="save_employee.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= htmlspecialchars($employee['id'] ?? '') ?>">
                        <input type="hidden" name="autosave_mode" id="autosave_mode" value="0">
                        
                        <!-- Personal Information Section -->
                        <div id="personal-section" class="section active">
                            <h4 class="text-secondary border-bottom pb-2 mb-3">Personal Information</h4>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label>First Name <span class="required">*</span></label>
                                    <input type="text" name="first_name" id="first_name" class="form-control" value="<?= htmlspecialchars($employee['first_name'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label>Last Name <span class="required">*</span></label>
                                    <input type="text" name="last_name" id="last_name" class="form-control" value="<?= htmlspecialchars($employee['last_name'] ?? '') ?>">
                                </div>
                             
<div class="col-md-6">
    <label>Employee Number</label>
    <input type="text" name="employee_no" id="employee_no" class="form-control" value="<?= htmlspecialchars($employee['employee_no'] ?? '') ?>">
    <div class="small-note">Enter employee number to auto-fill details</div>
</div>
                                <div class="col-md-6">
                                    <label>CNIC <span class="required">*</span></label>
                                    <input type="text" id="cnic" class="form-control" maxlength="15" placeholder="xxxxx-xxxxxxx-x" value="<?php
                                        if (!empty($employee['cnic'])) {
                                            $cn = preg_replace('/\D/', '', $employee['cnic']);
                                            if (strlen($cn) === 13) echo substr($cn,0,5).'-'.substr($cn,5,7).'-'.substr($cn,12,1);
                                        }
                                    ?>">
                                    <input type="hidden" name="cnic" id="cnic_raw" value="<?= htmlspecialchars($employee['cnic'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label>Marital Status</label>
                                    <select name="marital_status" class="form-select">
                                        <?php
                                        $options = ['Single','Married','Divorced','Widowed'];
                                        foreach($options as $opt) {
                                            $sel = ($employee['marital_status'] ?? '') == $opt ? 'selected' : '';
                                            echo "<option value='".htmlspecialchars($opt)."' $sel>".htmlspecialchars($opt)."</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label>Permanent Address</label>
                                    <textarea name="permanent_address" id="permanent_address" class="form-control"><?= htmlspecialchars($employee['permanent_address'] ?? '') ?></textarea>
                                </div>
                                <div class="col-md-6">
                                    <label>Current Address</label>
                                    <textarea name="current_address" id="current_address" class="form-control"><?= htmlspecialchars($employee['current_address'] ?? '') ?></textarea>
                                </div>
                                <div class="col-md-6">
                                    <label>Contact Number</label>
                                    <input type="text" id="contact_number" name="contact_number" class="form-control" maxlength="12" placeholder="92XXXXXXXXXX" value="<?= htmlspecialchars($employee['contact_number'] ?? '') ?>">
                                    <div class="small-note">Format: country code + 10 digits, e.g. 92XXXXXXXXXX</div>
                                </div>
                                <div class="col-md-6">
                                    <label>Next of Kin Name <span class="required">*</span></label>
                                    <input type="text" name="next_of_kin_name" id="next_of_kin_name" class="form-control" value="<?= htmlspecialchars($employee['next_of_kin_name'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label>Next of Kin CNIC <span class="required">*</span></label>
                                    <input type="text" id="next_of_kin_cnic" class="form-control" maxlength="15" placeholder="xxxxx-xxxxxxx-x" value="<?php
                                        if (!empty($employee['next_of_kin_cnic'])) {
                                            $cn = preg_replace('/\D/', '', $employee['next_of_kin_cnic']);
                                            if (strlen($cn) === 13) echo substr($cn,0,5).'-'.substr($cn,5,7).'-'.substr($cn,12,1);
                                        }
                                    ?>">
                                    <input type="hidden" name="next_of_kin_cnic_raw" id="next_of_kin_cnic_raw" value="<?= htmlspecialchars($employee['next_of_kin_cnic'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label>Nationality <span class="required">*</span></label>
                                    <select name="nationality" id="nationality" class="form-select">
                                        <option value="Pakistani" <?= ($employee['nationality'] ?? 'Pakistani') === 'Pakistani' ? 'selected' : '' ?>>Pakistani</option>
                                        <option value="Other" <?= ($employee['nationality'] ?? '') === 'Other' ? 'selected' : '' ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label>Blood Group <span class="required">*</span></label>
                                    <input type="text" name="blood_group" id="blood_group" class="form-control" value="<?= htmlspecialchars($employee['blood_group'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label>Emergency Contact Name</label>
                                    <input type="text" name="emergency_contact_name" class="form-control" value="<?= htmlspecialchars($employee['emergency_contact_name'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label>Emergency Contact Number</label>
                                    <input type="text" name="emergency_contact_number" class="form-control" value="<?= htmlspecialchars($employee['emergency_contact_number'] ?? '') ?>">
                                </div>
                            </div>
                            
                            <h5 class="mt-4 mb-3">Upload Documents</h5>
                            <div class="row">
                                <?php
                                $files = ['cnic_front'=>'CNIC Front','cnic_back'=>'CNIC Back','passport_photo'=>'Passport Photo','frc'=>'Family Registration Certificate (FRC)'];
                                foreach($files as $f => $label):
                                ?>
                                <div class="col-md-6 mb-3">
                                    <label class="fw-semibold"><?= htmlspecialchars($label) ?> <?php if (in_array($f, ['cnic_front','cnic_back','passport_photo'])) echo '<span class="required">*</span>'; ?> (Upload Image or PDF)</label>
                                    <?php if(!empty($employee[$f])) :
                                        $fileExt = strtolower(pathinfo($employee[$f], PATHINFO_EXTENSION));
                                        if(in_array($fileExt, ['jpg','jpeg','png'])): ?>
                                            <div class="file-preview"><img src="<?= htmlspecialchars($employee[$f]) ?>" alt="<?= $label ?>"></div>
                                        <?php else: ?>
                                            <div><a href="<?= htmlspecialchars($employee[$f]) ?>" target="_blank" class="link-primary">View Uploaded File</a></div>
                                        <?php endif;
                                        echo '<input type="hidden" name="'.htmlspecialchars($f).'_old" value="'.htmlspecialchars($employee[$f]).'">';
                                    endif; ?>
                                    <input type="file" name="<?= htmlspecialchars($f) ?>" class="form-control mt-1 personal-file-input" accept=".jpg,.jpeg,.png,.pdf">
                                </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="text-end mt-4">
                                <button type="button" class="btn btn-outline-secondary me-2" id="prev-personal">Previous</button>
                                <button type="button" class="btn btn-primary" id="next-personal">Next</button>
                            </div>
                        </div>
                        
                        <!-- Qualifications Section -->
                        <div id="qualifications-section" class="section">
                            <h4 class="text-secondary border-bottom pb-2 mb-3">Qualifications / Certifications</h4>
                            <button type="button" class="btn btn-sm btn-success mb-2" id="addQualificationBtn">+ Add Qualification</button>
                            
                            <div id="qualification-list">
                              <?php foreach($qualifications as $qidx => $q): ?>
<div class="mb-2 d-flex align-items-center gap-2 qual-row">
    <input type="hidden" name="qualification_id[]" value="<?= (int)$q['id'] ?>">
    <input type="text" name="qualification_name[]" class="form-control w-50" value="<?= htmlspecialchars($q['qualification_name']) ?>" placeholder="Qualification Name">
    <input type="file" name="certificate_file[]" class="form-control w-25 cert-file-input">
    <?php if(!empty($q['certificate_file'])): ?>
        <a href="<?= htmlspecialchars($q['certificate_file']) ?>" target="_blank" class="btn btn-link p-0">View File</a>
    <?php endif; ?>
    <input type="hidden" name="certificate_file_old[]" value="<?= htmlspecialchars($q['certificate_file'] ?? '') ?>">
    <span class="remove-btn" style="cursor:pointer; color:red; font-size:20px; font-weight:bold;">×</span>
</div>
<?php endforeach; ?>
                            </div>
                            
                            <div class="text-end mt-4">
                                <button type="button" class="btn btn-outline-secondary me-2" id="prev-qualifications">Previous</button>
                                <button type="button" class="btn btn-primary" id="next-qualifications">Next</button>
                            </div>
                        </div>
                        
                        <!-- Relatives Section -->
                        <div id="relatives-section" class="section">
                            <h4 class="text-secondary border-bottom pb-2 mb-3">Relatives / Dependents</h4>
                            
                            <!-- Relation Selection Dropdown -->
                            <div class="relation-card" id="relation-selection-card" style="display: none;">
                                <div class="card-header">
                                    <h5 class="mb-0">Select Existing Relation</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="relation-select">Select Relation</label>
                                            <select id="relation-select" class="form-select">
                                                <option value="">-- Select a Relation --</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 d-flex align-items-end">
                                            <button type="button" class="btn btn-primary" id="load-relation-btn">
                                                <i class="fas fa-download me-2"></i>Load Relation Data
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="relative-form-fields">
                                <h5 class="mb-3">Add/Edit Relative Details</h5>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label>Employee Number <span class="required">*</span></label>
                                        <input type="text" id="modal_employee_no" class="form-control" readonly>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Family Number</label>
                                        <input type="text" id="modal_family_no" class="form-control" readonly>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Name <span class="required">*</span></label>
                                        <input type="text" id="modal_name" class="form-control" readonly>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Relation <span class="required">*</span></label>
                                        <select name="modal_relation_type" id="modal_relation_type" class="form-select" disabled>
                                            <option value="">Select</option>
                                            <option value="Spouse">Spouse</option>
                                            <option value="Child">Daughter</option>
                                            <option value="Child">Son</option>
                                            <option value="Parent">Mother</option>
                                            <option value="Parent">Father</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Date of Birth <span class="required">*</span></label>
                                        <input type="date" id="modal_dob" class="form-control" readonly>
                                    </div>
                                    <div class="col-md-4">
                                        <label>CNIC <span class="required">*</span></label>
                                        <input type="text" id="modal_cnic" class="form-control" maxlength="15" placeholder="xxxxx-xxxxxxx-x" readonly>
                                        <input type="hidden" id="modal_cnic_raw">
                                    </div>
                                    <div class="col-md-4">
                                        <label>Blood Group <span class="required">*</span></label>
                                        <select name="modal_blood_group" id="modal_blood_group" class="form-select" disabled>
                                            <option value="">Select</option>
                                            <option value="A+">A+</option>
                                            <option value="A-">A-</option>
                                            <option value="B+">B+</option>
                                            <option value="B-">B-</option>
                                            <option value="AB+">AB+</option>
                                            <option value="AB-">AB-</option>
                                            <option value="O+">O+</option>
                                            <option value="O-">O-</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Nationality <span class="required">*</span></label>
                                        <select id="modal_nationality" class="form-select" disabled>
                                            <option value="Pakistani">Pakistani</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Marital Status</label>
                                        <select id="modal_marital_status" class="form-select" disabled>
                                            <option value="Single">Single</option>
                                            <option value="Married">Married</option>
                                            <option value="Divorced">Divorced</option>
                                            <option value="Widowed">Widowed</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label>ID Type <span class="required">*</span></label>
                                        <select name="modal_id_type" id="modal_id_type" class="form-select">
                                            <option value="">Select</option>
                                            <option value="CNIC">CNIC</option>
                                            <option value="B-Form">B-Form</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Availing Medical Elsewhere?</label>
                                        <select id="modal_medical" class="form-select">
                                            <option value="0">No</option>
                                            <option value="1">Yes</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <hr class="my-3">
                                
                                <h6 class="mb-3">Upload Documents</h6>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label>ID Front <span class="required">*</span></label>
                                        <input type="file" id="modal_cnic_front" class="form-control" accept=".jpg,.jpeg,.png,.pdf">
                                        <div class="small-note">JPG, PNG or PDF (Max 5MB)</div>
                                    </div>
                                    <div class="col-md-4">
                                        <label>ID Back <span class="required">*</span></label>
                                        <input type="file" id="modal_cnic_back" class="form-control" accept=".jpg,.jpeg,.png,.pdf">
                                        <div class="small-note">JPG, PNG or PDF (Max 5MB)</div>
                                    </div>
                                    <div class="col-md-4">
                                        <label>Passport Photo <span class="required">*</span></label>
                                        <input type="file" id="modal_passport_photo" class="form-control" accept=".jpg,.jpeg,.png">
                                        <div class="small-note">JPG or PNG (Max 5MB)</div>
                                    </div>
                                </div>
                                
                                <div class="text-center mt-4">
                                    <button type="button" class="btn btn-primary" id="addRelativeBtn">
                                        <i class="fas fa-plus-circle me-2"></i>Add Relative to List
                                    </button>
                                    <button type="button" class="btn btn-secondary ms-2" id="clearRelationBtn">
                                        <i class="fas fa-times me-2"></i>Clear Form
                                    </button>
                                </div>
                            </div>
                            
                            <div id="relatives-table">
                                <h5 class="mb-3">List of Added Relatives</h5>
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover align-middle">
                                        <thead>
                                            <tr class="relative-row">
                                                <th>Name</th>
                                                <th>Relation</th>
                                                <th>ID Type</th>
                                                <th>ID Number</th>
                                                <th>Date of Birth</th>
                                                <th>Blood Group</th>
                                                <th>Medical Elsewhere</th>
                                                <th>Files</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($relatives as $r): ?>
                                                <tr data-rid="<?= (int)$r['id'] ?>">
                                                    <td><?= htmlspecialchars($r['first_name'] . ' ' . $r['last_name']) ?></td>
                                                    <td><?= htmlspecialchars($r['relation_type']) ?></td>
                                                    <td><?= htmlspecialchars($r['id_type'] ?? 'CNIC') ?></td>
                                                    <td><?= htmlspecialchars($r['cnic']) ?></td>
                                                    <td><?= htmlspecialchars($r['date_of_birth']) ?></td>
                                                    <td><?= htmlspecialchars($r['blood_group'] ?? '') ?></td>
                                                    <td><?= $r['availing_medical_elsewhere'] ? 'Yes' : 'No' ?></td>
                                                    <td>
                                                        <div class="d-flex gap-2">
                                                            <?php if (!empty($r['cnic_front'])): ?><a href="<?= htmlspecialchars($r['cnic_front']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">Front</a><?php endif; ?>
                                                            <?php if (!empty($r['cnic_back'])): ?><a href="<?= htmlspecialchars($r['cnic_back']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">Back</a><?php endif; ?>
                                                            <?php if (!empty($r['passport_photo'])): ?><a href="<?= htmlspecialchars($r['passport_photo']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">Photo</a><?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="deleteRelativeExisting(<?= (int)$r['id'] ?>, this)">Delete</button>
                                                    </td>
                                                </tr>
                                                <tr style="display:none;">
                                                    <td colspan="9">
                                                        <div id="existing-rel-hidden-<?= (int)$r['id'] ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relation_type[]" value="<?= htmlspecialchars($r['relation_type']) ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_first_name[]" value="<?= htmlspecialchars($r['first_name']) ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_last_name[]" value="<?= htmlspecialchars($r['last_name']) ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_id_type[]" value="<?= htmlspecialchars($r['id_type'] ?? 'CNIC') ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_cnic[]" value="<?= htmlspecialchars($r['cnic']) ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_dob[]" value="<?= htmlspecialchars($r['date_of_birth']) ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_blood_group[]" value="<?= htmlspecialchars($r['blood_group'] ?? '') ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="availing_medical_elsewhere[]" value="<?= htmlspecialchars($r['availing_medical_elsewhere']) ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_cnic_front_old[]" value="<?= htmlspecialchars($r['cnic_front'] ?? '') ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_cnic_back_old[]" value="<?= htmlspecialchars($r['cnic_back'] ?? '') ?>">
                                                            <input data-rel-id="<?= (int)$r['id'] ?>" type="hidden" name="relative_photo_old[]" value="<?= htmlspecialchars($r['passport_photo'] ?? '') ?>">
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                            <div id="hidden-relative-fields" style="display:none;"></div>
                            
                            <div class="text-end mt-4">
                                <button type="button" class="btn btn-outline-secondary me-2" id="prev-relatives">Previous</button>
                            </div>
                        </div>
                    </form>
                    
                    <div class="form-actions no-print">
                        <button type="submit" form="employeeForm" name="action" value="draft" class="btn btn-warning me-2">💾 Save Draft</button>
                        <button type="submit" form="employeeForm" name="action" value="submit" class="btn btn-primary">🚀 Submit</button>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<script src="js/js/bootstrap.bundle.min.js"></script>
<script>
console.log('Autosave script loaded');

// Employee number auto-fill functionality
document.getElementById('employee_no')?.addEventListener('blur', function() {
    const employeeNo = this.value.trim();
    if (!employeeNo) return;
    
    // Show loading indicator
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-info mt-2';
    alertDiv.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading employee data...';
    
    // Remove any existing alerts
    const existingAlert = this.parentNode.querySelector('.alert');
    if (existingAlert) existingAlert.remove();
    
    // Add the new alert
    this.parentNode.appendChild(alertDiv);
    
    // Add timestamp to prevent caching
    const timestamp = new Date().getTime();
    
    fetch(`get_employee_data.php?employee_no=${encodeURIComponent(employeeNo)}&t=${timestamp}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Remove loading alert
            alertDiv.remove();
            
            if (data.success) {
                const emp = data.data;
                const relations = data.relations || [];
                
                // Helper function to safely set element value
                const safeSetValue = (elementId, value) => {
                    const element = document.getElementById(elementId);
                    if (element) {
                        element.value = value;
                        return true;
                    }
                    return false;
                };
                
                // Helper function to safely set select value
                const safeSetSelectValue = (selector, value) => {
                    const element = document.querySelector(selector);
                    if (element) {
                        element.value = value;
                        return true;
                    }
                    return false;
                };
                
                // Fill personal information fields with null checks
                safeSetValue('first_name', emp.first_name || '');
                safeSetValue('last_name', emp.last_name || '');
                
                // Format and fill CNIC
                if (emp.cnic) {
                    const cn = emp.cnic.replace(/\D/g, '');
                    if (cn.length === 13) {
                        const formattedCnic = cn.slice(0,5) + '-' + cn.slice(5,12) + '-' + cn.slice(12);
                        safeSetValue('cnic', formattedCnic);
                        safeSetValue('cnic_raw', cn);
                    }
                }
                
                // Handle marital status
                if (emp.marital_status) {
                    safeSetSelectValue('[name="marital_status"]', emp.marital_status);
                }
                
                safeSetValue('permanent_address', emp.permanent_address || '');
                safeSetValue('current_address', emp.current_address || '');
                safeSetValue('contact_number', emp.contact_number || '');
                safeSetValue('next_of_kin_name', emp.next_of_kin_name || '');
                
                // Format and fill Next of Kin CNIC
                if (emp.next_of_kin_cnic) {
                    const cn = emp.next_of_kin_cnic.replace(/\D/g, '');
                    if (cn.length === 13) {
                        const formattedCnic = cn.slice(0,5) + '-' + cn.slice(5,12) + '-' + cn.slice(12);
                        safeSetValue('next_of_kin_cnic', formattedCnic);
                        safeSetValue('next_of_kin_cnic_raw', cn);
                    }
                }
                
                safeSetValue('nationality', emp.nationality || 'Pakistani');
                safeSetValue('blood_group', emp.blood_group || '');
                safeSetValue('emergency_contact_name', emp.emergency_contact_name || '');
                safeSetValue('emergency_contact_number', emp.emergency_contact_number || '');
                
                // Populate relations dropdown and show the card
                populateRelationsDropdown(relations);
                
                // Show a success message
                const successDiv = document.createElement('div');
                successDiv.className = 'alert alert-success mt-2';
                successDiv.innerHTML = '<i class="fas fa-check-circle me-2"></i>Employee details loaded successfully. Please verify and upload required documents.';
                
                // Add the new alert
                this.parentNode.appendChild(successDiv);
                
                // Auto-save the populated data
                setTimeout(() => autosaveDraft(), 1000);
            } else {
                // Show error message
                const errorDiv = document.createElement('div');
                errorDiv.className = 'alert alert-danger mt-2';
                errorDiv.innerHTML = `<i class="fas fa-exclamation-triangle me-2"></i>${data.message}`;
                
                // Add the new alert
                this.parentNode.appendChild(errorDiv);
            }
        })
        .catch(error => {
            console.error('Error fetching employee data:', error);
            
            // Remove loading alert
            alertDiv.remove();
            
            // Show detailed error message
            const errorDiv = document.createElement('div');
            errorDiv.className = 'alert alert-danger mt-2';
            errorDiv.innerHTML = `<i class="fas fa-exclamation-triangle me-2"></i>Error loading employee details: ${error.message}`;
            
            // Add the new alert
            this.parentNode.appendChild(errorDiv);
        });
});

// Function to populate relations dropdown
function populateRelationsDropdown(relations) {
    const dropdown = document.getElementById('relation-select');
    const card = document.getElementById('relation-selection-card');
    
    if (!dropdown) return;
    
    // Clear existing options except the first one
    while (dropdown.options.length > 1) {
        dropdown.remove(1);
    }
    
    // Add relations to dropdown
    if (relations && relations.length > 0) {
        relations.forEach(relation => {
            const option = document.createElement('option');
            option.value = relation.id;
            option.textContent = `${relation.name} (${relation.relation})`;
            option.dataset.relation = JSON.stringify(relation);
            dropdown.appendChild(option);
        });
        
        // Show the relation selection card
        if (card) {
            card.style.display = 'block';
        }
    } else {
        // Hide the relation selection card if no relations
        if (card) {
            card.style.display = 'none';
        }
    }
}

// Load relation data when button is clicked
document.getElementById('load-relation-btn')?.addEventListener('click', function() {
    const dropdown = document.getElementById('relation-select');
    const selectedOption = dropdown.options[dropdown.selectedIndex];
    
    if (!selectedOption || !selectedOption.value) {
        alert('Please select a relation first');
        return;
    }
    
    try {
        const relation = JSON.parse(selectedOption.dataset.relation);
        fillRelationForm(relation);
    } catch (error) {
        console.error('Error parsing relation data:', error);
        alert('Error loading relation data');
    }
});

// Function to fill relation form with data
function fillRelationForm(relation) {
    // Helper function to safely set element value
    const safeSetValue = (elementId, value, readonly = false) => {
        const element = document.getElementById(elementId);
        if (element) {
            element.value = value;
            element.readOnly = readonly;
            if (readonly) {
                element.classList.add('readonly-field');
            } else {
                element.classList.remove('readonly-field');
            }
            return true;
        }
        return false;
    };
    
    // Helper function to safely set select value
    const safeSetSelectValue = (selector, value, disabled = false) => {
        const element = document.querySelector(selector);
        if (element) {
            element.value = value;
            element.disabled = disabled;
            if (disabled) {
                element.classList.add('readonly-field');
            } else {
                element.classList.remove('readonly-field');
            }
            return true;
        }
        return false;
    };
    
    // Fill form fields with relation data and make them readonly
    safeSetValue('modal_employee_no', relation.employee_no || '', true);
    safeSetValue('modal_family_no', relation.family_no || '', true);
    safeSetValue('modal_name', relation.name || '', true);
    safeSetSelectValue('#modal_relation_type', relation.relation || '', true);
    safeSetValue('modal_dob', relation.date_of_birth || '', true);
    
    // Format and fill CNIC
    if (relation.cnic) {
        const cn = relation.cnic.replace(/\D/g, '');
        if (cn.length === 13) {
            const formattedCnic = cn.slice(0,5) + '-' + cn.slice(5,12) + '-' + cn.slice(12);
            safeSetValue('modal_cnic', formattedCnic, true);
            safeSetValue('modal_cnic_raw', cn, true);
        }
    }
    
    safeSetSelectValue('#modal_blood_group', relation.blood_group || '', true);
    safeSetSelectValue('#modal_nationality', relation.nationality || 'Pakistani', true);
    safeSetSelectValue('#modal_marital_status', relation.marital_status || '', true);
    
    // Keep these fields editable
    safeSetSelectValue('#modal_id_type', 'CNIC', false);
    safeSetSelectValue('#modal_medical', '0', false);
    
    // Show a success message
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-info mt-2';
    alertDiv.innerHTML = '<i class="fas fa-info-circle me-2"></i>Relation data loaded. Some fields are pre-filled and cannot be changed.';
    
    // Remove any existing alerts
    const existingAlert = document.querySelector('#relative-form-fields .alert');
    if (existingAlert) existingAlert.remove();
    
    // Add the new alert
    document.getElementById('relative-form-fields').appendChild(alertDiv);
}

// Clear relation form
document.getElementById('clearRelationBtn')?.addEventListener('click', function() {
    // Clear all form fields
    const fields = [
        'modal_employee_no', 'modal_family_no', 'modal_name',
        'modal_dob', 'modal_cnic', 'modal_cnic_raw'
    ];
    
    fields.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.value = '';
            element.readOnly = false;
            element.classList.remove('readonly-field');
        }
    });
    
    const selects = [
        '#modal_relation_type', '#modal_blood_group', 
        '#modal_nationality', '#modal_marital_status',
        '#modal_id_type', '#modal_medical'
    ];
    
    selects.forEach(selector => {
        const element = document.querySelector(selector);
        if (element) {
            element.value = '';
            element.disabled = false;
            element.classList.remove('readonly-field');
        }
    });
    
    // Clear file inputs
    const fileInputs = ['modal_cnic_front', 'modal_cnic_back', 'modal_passport_photo'];
    fileInputs.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.value = '';
        }
    });
    
    // Remove any alerts
    const existingAlert = document.querySelector('#relative-form-fields .alert');
    if (existingAlert) existingAlert.remove();
});

// Update the addRelativeBtn function to handle the new form structure
document.getElementById('addRelativeBtn')?.addEventListener('click', function(){
    const employeeNo = document.getElementById('modal_employee_no').value.trim();
    const familyNo = document.getElementById('modal_family_no').value.trim();
    const name = document.getElementById('modal_name').value.trim();
    const relationType = document.getElementById('modal_relation_type').value.trim();
    const dob = document.getElementById('modal_dob').value;
    const cnicDisplay = document.getElementById('modal_cnic').value.trim();
    const bloodGroup = document.getElementById('modal_blood_group').value.trim();
    const nationality = document.getElementById('modal_nationality').value.trim();
    const maritalStatus = document.getElementById('modal_marital_status').value.trim();
    const idType = document.getElementById('modal_id_type').value.trim();
    const medical = document.getElementById('modal_medical').value;
    const frontFile = document.getElementById('modal_cnic_front').files[0];
    const backFile = document.getElementById('modal_cnic_back').files[0];
    const photoFile = document.getElementById('modal_passport_photo').files[0];

    // if (!employeeNo || !name || !relationType || !cnicDisplay || !dob || !bloodGroup || !nationality || !frontFile || !backFile || !photoFile) {
    //     alert('Please fill all required fields and attach all documents for the relative.');
    //     return;
    // }

    const rawCnic = cnicDisplay.replace(/\D/g,'');
    const tempId = makeTempId();

    relativesData.push({
        tempId: tempId, 
        employee_no: employeeNo,
        family_no: familyNo,
        name: name,
        relation_type: relationType, 
        id_type: idType,
        cnic: rawCnic, 
        dob: dob, 
        blood_group: bloodGroup,
        nationality: nationality,
        marital_status: maritalStatus,
        medical: medical,
        files: { front: frontFile, back: backFile, photo: photoFile }
    });

    addRelativeToTable({
        tempId: tempId, 
        name: name,
        relation_type: relationType,
        id_type: idType,
        cnic: cnicDisplay, 
        dob: dob, 
        blood_group: bloodGroup,
        medical: medical, 
        isNew: true
    });

    // Clear the form fields
    document.getElementById('clearRelationBtn').click();

    // Autosave relatives immediately after adding
    autoSaveFullDraftWithFiles();
});

// Update the addRelativeToTable function to handle the new structure
function addRelativeToTable(relative) {
    const tbody = document.querySelector('#relatives-table tbody');
    const tr = document.createElement('tr');

    const identifier = relative.isNew ? `data-temp-id` : `data-rid`;
    tr.setAttribute(identifier, relative.tempId || relative.id);

    tr.innerHTML = `
        <td>${escapeHtml(relative.name)}</td>
        <td>${escapeHtml(relative.relation_type)}</td>
        <td>${escapeHtml(relative.id_type)}</td>
        <td>${escapeHtml(relative.cnic)}</td>
        <td>${escapeHtml(relative.dob)}</td>
        <td>${escapeHtml(relative.blood_group)}</td>
        <td>${relative.medical == '1' ? 'Yes' : 'No'}</td>
        <td>${relative.isNew ? 'Attached' : '<div class="d-flex gap-2">' + (relative.cnic_front ? `<a href="${relative.cnic_front}" target="_blank" class="btn btn-sm btn-outline-secondary">Front</a>` : '') + (relative.cnic_back ? `<a href="${relative.cnic_back}" target="_blank" class="btn btn-sm btn-outline-secondary">Back</a>` : '') + (relative.passport_photo ? `<a href="${relative.passport_photo}" target="_blank" class="btn btn-sm btn-outline-secondary">Photo</a>` : '') + '</div>'}</td>
        <td><button type="button" class="btn btn-sm btn-outline-danger" onclick="removeRelative('${relative.tempId || relative.id}', this, ${relative.isNew})">Delete</button></td>
    `;
    tbody.appendChild(tr);
}

// Add hidden fields for form submission
function appendRelativesToFormData(fd){
    relativesData.forEach((rel, index) => {
        fd.append('relation_type[]', rel.relation_type);
        fd.append('relative_id_type[]', rel.id_type);
        fd.append('relative_employee_no[]', rel.employee_no || '');
        fd.append('relative_family_no[]', rel.family_no || '');
        fd.append('relative_name[]', rel.name);
        fd.append('relative_first_name[]', rel.name); // For compatibility
        fd.append('relative_last_name[]', ''); // Empty for compatibility
        fd.append('relative_cnic[]', rel.cnic);
        fd.append('relative_dob[]', rel.dob);
        fd.append('relative_blood_group[]', rel.blood_group);
        fd.append('relative_nationality[]', rel.nationality);
        fd.append('relative_marital_status[]', rel.marital_status);
        fd.append('availing_medical_elsewhere[]', rel.medical);
        if (rel.files && rel.files.front) fd.append('relative_cnic_front[]', rel.files.front);
        if (rel.files && rel.files.back) fd.append('relative_cnic_back[]', rel.files.back);
        if (rel.files && rel.files.photo) fd.append('relative_photo[]', rel.files.photo);
    });
}

// Rest of the existing JavaScript code (formatCnicStr, escapeHtml, etc.)
function formatCnicStr(v){
    v = String(v || '').replace(/\D/g,'').slice(0,13);
    if (v.length > 5 && v.length <= 12) v = v.slice(0,5) + '-' + v.slice(5);
    else if (v.length > 12) v = v.slice(0,5) + '-' + v.slice(5,12) + '-' + v.slice(12);
    return v;
}
function escapeHtml(str){ return String(str).replace(/[&<>"'`=\/]/g, function(s){ return {"&":"&amp;","<":"&lt;",">":"&gt;",'"': "&quot;","'":"&#39;","/":"&#x2F;","`":"&#x60;","=":"&#x3D;"}[s]; }); }

function updateMainCnicRaw(){ const disp=document.getElementById('cnic'); const raw=document.getElementById('cnic_raw'); if(disp && raw) raw.value = disp.value.replace(/\D/g,''); }
function updateNextOfKinCnicRaw(){ const disp=document.getElementById('next_of_kin_cnic'); const raw=document.getElementById('next_of_kin_cnic_raw'); if(disp && raw) raw.value = disp.value.replace(/\D/g,''); }

document.querySelectorAll('#cnic,#next_of_kin_cnic,#modal_cnic').forEach(el => {
    if(el) el.placeholder = 'xxxxx-xxxxxxx-x';
    if(el) el.addEventListener('input', e => {
        e.target.value = formatCnicStr(e.target.value);
        if(e.target.id === 'cnic') updateMainCnicRaw();
        if(e.target.id === 'next_of_kin_cnic') updateNextOfKinCnicRaw();
        if(e.target.id === 'modal_cnic') document.getElementById('modal_cnic_raw').value = e.target.value.replace(/\D/g,'');
    });
});

document.querySelectorAll('.sidebar .nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        
        const section = this.getAttribute('data-section');
        if (!section) return;
        
        // Update active nav link
        document.querySelectorAll('.sidebar .nav-link').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
        
        // Show corresponding section
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.getElementById(section + '-section').classList.add('active');
        
        // Update step indicator
        if (section === 'personal') updateStepIndicator(1);
        else if (section === 'qualifications') updateStepIndicator(2);
        else if (section === 'relatives') updateStepIndicator(3);
    });
});

// Step indicator
function updateStepIndicator(step) {
    document.querySelectorAll('.step').forEach((s, index) => {
        if (index < step) {
            s.classList.add('active');
            if (index < step - 1) s.classList.add('completed');
        } else {
            s.classList.remove('active', 'completed');
        }
    });
}

// Navigation buttons
document.getElementById('next-personal')?.addEventListener('click', function() {
    document.querySelector('[data-section="qualifications"]').click();
});

document.getElementById('prev-qualifications')?.addEventListener('click', function() {
    document.querySelector('[data-section="personal"]').click();
});

document.getElementById('next-qualifications')?.addEventListener('click', function() {
    document.querySelector('[data-section="relatives"]').click();
});

document.getElementById('prev-relatives')?.addEventListener('click', function() {
    document.querySelector('[data-section="qualifications"]').click();
});

// Download PDF button
document.getElementById('download-pdf')?.addEventListener('click', function(e) {
    e.preventDefault();
    const formId = new URLSearchParams(window.location.search).get('id');
    if (formId) {
        window.open('generate_pdf.php?id=' + formId, '_blank');
    }
});

// Autosave logic
let autosaveTimer = null;
function gatherAutosaveFormData(){
    const form = document.getElementById('employeeForm');
    if (!form) return null;
    
    const fd = new FormData();
    fd.append('autosave', '1');
    const id = form.querySelector('input[name="id"]').value;
    if (id) fd.append('id', id);
    updateMainCnicRaw(); updateNextOfKinCnicRaw();
    const fields = ['first_name','last_name','cnic','marital_status','permanent_address','current_address','contact_number','next_of_kin_name','next_of_kin_cnic_raw','nationality','blood_group','emergency_contact_name','emergency_contact_number','employee_no'];
    fields.forEach(k => { const el = form.querySelector('[name="'+k+'"]'); if (el) fd.append(k, el.value || ''); });
    return fd;
}
function autosaveDraftDebounced(){ if (autosaveTimer) clearTimeout(autosaveTimer); autosaveTimer = setTimeout(autosaveDraft, 700); }
function autosaveDraft(){ 
    const fd = gatherAutosaveFormData();
    if (!fd) return;
    
    fetch('autosave.php', { method:'POST', body:fd, credentials:'same-origin' }).then(r=>r.json()).then(json=>{ 
        if(json && (json.success==1 || json.success===true) && json.id){ 
            document.querySelector('input[name="id"]').value = json.id; 
            console.log('autosave ok id=' + json.id); 
        } 
    }).catch(e => console.log('autosave error', e)); 
}
function attachAutosaveOnBlur(){
    const selector = '#employeeForm input[type="text"], #employeeForm input[type="date"], #employeeForm textarea, #employeeForm select';
    document.querySelectorAll(selector).forEach(el => {
        if(!el) return; if(el.type === 'file') return;
        el.addEventListener('blur', function(){ 
            if(this.id === 'cnic') updateMainCnicRaw(); 
            if(this.id === 'next_of_kin_cnic') updateNextOfKinCnicRaw(); 
            autosaveDraftDebounced(); 
        });
    });
}
attachAutosaveOnBlur();

// Relatives data management
let relativesData = [];
function makeTempId(){ return String(Date.now()) + Math.floor(Math.random()*1000); }

// Autosave with files
let savingWithFiles = false;
function autoSaveFullDraftWithFiles(callback){
    if(savingWithFiles) return; savingWithFiles = true;
    const form = document.getElementById('employeeForm'); 
    if (!form) {
        savingWithFiles = false;
        return;
    }
    
    updateMainCnicRaw(); updateNextOfKinCnicRaw();
    const fd = new FormData(form); 
    appendRelativesToFormData(fd);
    fd.append('action','draft'); fd.append('autosave','1'); fd.append('ajax','1');
    fetch('save_employee.php', { method:'POST', body:fd, credentials:'same-origin' }).then(resp => resp.json()).then(json => {
        savingWithFiles = false; 
        if(json && json.success && json.id){ 
            document.querySelector('input[name="id"]').value = json.id; 
            console.log('Autosave with files successful');
        } else { 
            console.error('Autosave with files failed', json);
        }
    }).catch(err => { 
        savingWithFiles = false; 
        console.error('autosave-with-files failed', err); 
        if(callback) callback(err); 
    });
}

// Attach autosave to file inputs
document.querySelectorAll('.personal-file-input').forEach(inp => { 
    if(!inp) return; 
    inp.addEventListener('change', function(){ autoSaveFullDraftWithFiles(); }); 
});
function attachCertFileListeners(){ 
    document.querySelectorAll('.cert-file-input').forEach(inp=>{ 
        if(!inp) return; 
        inp.addEventListener('change', function(){ autoSaveFullDraftWithFiles(); }); 
    }); 
}
attachCertFileListeners();

// Qualifications logic
document.getElementById('addQualificationBtn')?.addEventListener('click', function(){
    const list = document.getElementById('qualification-list');
    const div = document.createElement('div'); 
    div.className = 'mb-2 d-flex align-items-center gap-2 qual-row';
    div.innerHTML = `<input type="text" name="qualification_name[]" class="form-control w-50" placeholder="Qualification Name"><input type="file" name="certificate_file[]" class="form-control w-25 cert-file-input"><input type="hidden" name="certificate_file_old[]" value=""><span class="remove-btn" style="cursor:pointer; color:red; font-size:20px; font-weight:bold;">×</span>`;
    list.appendChild(div);
    div.querySelector('.remove-btn').addEventListener('click', function(){ 
        if(confirm('Are you sure you want to remove this qualification?')) {
            div.remove(); 
            autoSaveFullDraftWithFiles(); 
        }
    });
    div.querySelector('.cert-file-input').addEventListener('change', function(){ autoSaveFullDraftWithFiles(); });
});

// Delete existing qualification
document.querySelectorAll('.qual-row').forEach(row => {
    const removeBtn = row.querySelector('.remove-btn');
    if(removeBtn) {
        removeBtn.addEventListener('click', function() {
            if(confirm('Are you sure you want to delete this qualification?')) {
                const qualId = row.querySelector('input[name="qualification_id[]"]')?.value;
                if(qualId) {
                    // Delete from backend
                    fetch('delete_qualification.php', { 
                        method: 'POST', 
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
                        body: 'id=' + encodeURIComponent(qualId) 
                    })
                    .then(res => res.json())
                    .then(json => {
                        if(json.success) {
                            row.remove();
                            console.log('Qualification deleted successfully');
                        } else {
                            alert("Failed to delete qualification: " + (json.error || 'Unknown error'));
                        }
                    })
                    .catch(err => { 
                        console.error('Delete error', err); 
                        alert('Error deleting qualification.'); 
                    });
                } else {
                    row.remove();
                }
            }
        });
    }
});

// Function to remove a relative from the table and the JS array
function removeRelative(id, btn, isNew) {
    if (confirm('Are you sure you want to remove this relative?')) {
        if (isNew) {
            relativesData = relativesData.filter(r => r.tempId !== id);
        }
        if(btn && btn.closest && btn.closest('tr')) btn.closest('tr').remove();
        
        // Autosave after removing
        autoSaveFullDraftWithFiles();
    }
}

// Function to delete an existing relative from the DB
function deleteRelativeExisting(relId, btn) {
    if (!confirm("Are you sure you want to delete this relative?")) return;
    fetch('delete_relative.php', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'id=' + encodeURIComponent(relId) })
    .then(res => res.json()).then(json => {
        if (json.success) {
            const row = btn.closest('tr');
            if (row) row.remove();
            const hiddenRow = row.nextElementSibling;
            if (hiddenRow && hiddenRow.querySelector(`#existing-rel-hidden-${relId}`)) {
                hiddenRow.remove();
            }
            // Autosave after deleting
            autoSaveFullDraftWithFiles();
        } else {
            alert("Failed to delete relative: " + (json.error || 'Unknown error'));
        }
    }).catch(err => { console.error('Delete error', err); alert('Error deleting record.'); });
}

// Form submission logic
document.getElementById('employeeForm')?.addEventListener('submit', function(e){
    updateMainCnicRaw(); updateNextOfKinCnicRaw();
    const actionButton = document.activeElement;
    const action = (actionButton && actionButton.name === 'action') ? actionButton.value : 'draft';
    if (action === 'submit') {
        const raw = document.getElementById('cnic_raw').value || '';
        const nextRaw = document.getElementById('next_of_kin_cnic_raw').value || '';
        if (!/^\d{13}$/.test(raw)) { alert('Please enter a valid CNIC (13 digits).'); e.preventDefault(); return false; }
        if (!/^\d{13}$/.test(nextRaw)) { alert('Please enter a valid Next of Kin CNIC (13 digits).'); e.preventDefault(); return false; }
    }
    e.preventDefault();
    const form = this; 
    const fd = new FormData(form);
    appendRelativesToFormData(fd);
    fd.append('action', action); 
    fd.append('ajax', '1');
    fetch('save_employee.php', { method:'POST', body: fd, credentials:'same-origin' }).then(r => r.json()).then(json => {
        if(json && json.success){ 
            if(json.id) document.querySelector('input[name="id"]').value = json.id; 
            if(json.redirect){ 
                window.location.href = json.redirect; 
                return; 
            } 
            if(action === 'submit'){ 
                alert('Form submitted successfully.'); 
                window.location.href = 'form.php'; 
            } else { 
                alert('Draft saved.'); 
            } 
        }
        else { 
            console.error('save failed', json); 
            const msg = (json && json.error) ? json.error : (json && json.errors ? json.errors.join('\n') : 'Unknown error'); 
            alert('Save failed. ' + msg); 
        }
    }).catch(err => { 
        console.error('save error', err); 
        alert('Save failed due to network/error. Check console.'); 
    });
    return false;
});
</script>
</body>
</html>