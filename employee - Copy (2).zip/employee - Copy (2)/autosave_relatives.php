<?php
session_start();
require_once 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$employee_id = $_POST['employee_id'] ?? 0;
$relative_id = $_POST['relative_id'] ?? null;
$relation_type = $_POST['relation_type'] ?? '';
$first_name = $_POST['first_name'] ?? '';
$last_name = $_POST['last_name'] ?? '';
$cnic = $_POST['cnic'] ?? '';
$date_of_birth = $_POST['date_of_birth'] ?? '';
$availing_medical_elsewhere = $_POST['availing_medical_elsewhere'] ?? 0;

// Handle file uploads
function uploadFile($file, $folder = 'uploads/') {
    if (!isset($_FILES[$file]) || $_FILES[$file]['error'] != 0) return null;
    $ext = pathinfo($_FILES[$file]['name'], PATHINFO_EXTENSION);
    $name = uniqid() . '.' . $ext;
    $path = $folder . $name;
    move_uploaded_file($_FILES[$file]['tmp_name'], $path);
    return $path;
}

$cnic_front = uploadFile('cnic_front');
$cnic_back = uploadFile('cnic_back');
$passport_photo = uploadFile('passport_photo');

try {
    if ($relative_id) {
        // Update existing record
        $sql = "UPDATE relatives 
                SET relation_type=?, first_name=?, last_name=?, cnic=?, date_of_birth=?, availing_medical_elsewhere=?";
        $params = [$relation_type, $first_name, $last_name, $cnic, $date_of_birth, $availing_medical_elsewhere];

        if ($cnic_front) { $sql .= ", cnic_front=?"; $params[] = $cnic_front; }
        if ($cnic_back) { $sql .= ", cnic_back=?"; $params[] = $cnic_back; }
        if ($passport_photo) { $sql .= ", passport_photo=?"; $params[] = $passport_photo; }

        $sql .= " WHERE id=? AND employee_id=?";
        $params[] = $relative_id;
        $params[] = $employee_id;

        $stmt = $conn->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['success' => true, 'message' => 'Updated successfully']);
    } else {
        // Insert new record
        $stmt = $conn->prepare("INSERT INTO relatives 
            (employee_id, relation_type, first_name, last_name, cnic, date_of_birth, availing_medical_elsewhere, cnic_front, cnic_back, passport_photo)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$employee_id, $relation_type, $first_name, $last_name, $cnic, $date_of_birth, $availing_medical_elsewhere, $cnic_front, $cnic_back, $passport_photo]);
        if ($stmt->rowCount() == 0) {
    echo json_encode(['success' => false, 'error' => 'Insert returned 0 rows']);
    exit;
}
        echo json_encode(['success' => true, 'relative_id' => $conn->lastInsertId(), 'message' => 'Inserted successfully']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
