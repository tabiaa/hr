<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    if (isset($_POST['ajax']) || isset($_POST['autosave'])) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>false, 'error'=>'Not logged in']);
        exit;
    } else {
        header('HTTP/1.1 403 Forbidden');
        echo "Not logged in";
        exit;
    }
}

 $action = $_POST['action'] ?? 'draft';
 $employee_id = !empty($_POST['id']) ? intval($_POST['id']) : null;
 $user_id = $_SESSION['user_id'];

 $uploadDirBase = __DIR__ . '/uploads/' . $user_id;
if (!is_dir($uploadDirBase)) mkdir($uploadDirBase, 0777, true);

// Generate employee number if not provided
function generateEmployeeNumber($pdo, $user_id) {
    // Get the current year
    $year = date('Y');
    
    // Count existing employees for this user in the current year
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM employees WHERE user_id = ? AND YEAR(created_at) = ?");
    $stmt->execute([$user_id, $year]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $count = $result['count'] + 1; // +1 for the new employee
    
    // Format: EMP-YYYY-NNNN (e.g., EMP-2023-0001)
    return "EMP-" . $year . "-" . str_pad($count, 4, '0', STR_PAD_LEFT);
}

function move_single_file($fileFieldName, $uploadDirBase, $prefix = ''){
    if (empty($_FILES[$fileFieldName]) || !isset($_FILES[$fileFieldName]['name'])) {
        return null;
    }
 
    if (is_array($_FILES[$fileFieldName]['name'])) {
        if ($_FILES[$fileFieldName]['error'][0] !== UPLOAD_ERR_OK) return null;
        $fname = $_FILES[$fileFieldName]['name'][0];
        $tmp = $_FILES[$fileFieldName]['tmp_name'][0];
    } else {
        if ($_FILES[$fileFieldName]['error'] !== UPLOAD_ERR_OK) return null;
        $fname = $_FILES[$fileFieldName]['name'];
        $tmp = $_FILES[$fileFieldName]['tmp_name'];
    }
    $ext = strtolower(pathinfo($fname, PATHINFO_EXTENSION));
    $safe = $prefix . uniqid('_') . '.' . $ext;
    $dest = $uploadDirBase . '/' . $safe;
    if (move_uploaded_file($tmp, $dest)) {
        return 'uploads/' . basename($uploadDirBase) . '/' . $safe;
    }
    return null;
}

function move_file_array_index($fileFieldName, $index, $uploadDirBase, $prefix=''){
    if (empty($_FILES[$fileFieldName]) || !isset($_FILES[$fileFieldName]['name'][$index]) ) return null;
    if ($_FILES[$fileFieldName]['error'][$index] !== UPLOAD_ERR_OK) return null;
    $fname = $_FILES[$fileFieldName]['name'][$index];
    $ext = strtolower(pathinfo($fname, PATHINFO_EXTENSION));
    $safe = $prefix . uniqid('_') . '.' . $ext;
    $tmp = $_FILES[$fileFieldName]['tmp_name'][$index];
    $dest = $uploadDirBase . '/' . $safe;
    if (move_uploaded_file($tmp, $dest)) {
        return 'uploads/' . basename($uploadDirBase) . '/' . $safe;
    }
    return null;
}

function postval($k){ return isset($_POST[$k]) ? trim($_POST[$k]) : ''; }

// Get employee number from form or generate a new one
 $employee_no = postval('employee_no');
if (empty($employee_no)) {
    $employee_no = generateEmployeeNumber($pdo, $user_id);
}

 $data = [
    'first_name' => postval('first_name'),
    'last_name'  => postval('last_name'),
    'cnic'       => preg_replace('/\D/','', postval('cnic')), 
    'marital_status' => postval('marital_status'),
    'permanent_address' => postval('permanent_address'),
    'current_address' => postval('current_address'),
    'contact_number' => postval('contact_number'),
    'next_of_kin_name' => postval('next_of_kin_name'),
    'next_of_kin_cnic' => preg_replace('/\D/','', postval('next_of_kin_cnic_raw') ?: postval('next_of_kin_cnic')),
    'nationality' => postval('nationality') ?: 'Pakistani',
    'blood_group' => postval('blood_group'),
    'emergency_contact_name' => postval('emergency_contact_name'),
    'emergency_contact_number' => postval('emergency_contact_number'),
    'draft' => $action === 'draft' ? 1 : 0,
    'user_id' => $user_id,
    'employee_no'=> $employee_no
];

 $errors = [];
if ($action === 'submit') {
    $required = [
        'first_name'=>'First name','last_name'=>'Last name','cnic'=>'CNIC',
        'next_of_kin_name'=>'Next of kin','next_of_kin_cnic'=>'Next of kin CNIC',
        'nationality'=>'Nationality','blood_group'=>'Blood group'
    ];
    foreach ($required as $k=>$label) {
        if (empty($data[$k])) $errors[] = "$label is required.";
    }
    if (!empty($data['cnic']) && !preg_match('/^\d{13}$/',$data['cnic'])) $errors[] = "CNIC must be 13 digits.";
    if (!empty($data['next_of_kin_cnic']) && !preg_match('/^\d{13}$/',$data['next_of_kin_cnic'])) $errors[] = "Next of kin CNIC must be 13 digits.";
}

if ($action === 'submit') {
    foreach (['cnic_front','cnic_back','passport_photo'] as $f) {
        $hasOld = !empty($_POST[$f.'_old']);
        $hasFile = !empty($_FILES[$f]['name']) && (is_array($_FILES[$f]['name']) ? $_FILES[$f]['error'][0] === UPLOAD_ERR_OK : $_FILES[$f]['error'] === UPLOAD_ERR_OK);
        if (!$hasOld && !$hasFile) $errors[] = ucfirst(str_replace('_',' ',$f))." is required.";
    }
}

if ($action === 'submit' && count($errors) > 0) {
    if (isset($_POST['ajax']) || isset($_POST['autosave'])) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>false,'errors'=>$errors]);
        exit;
    }
    echo "<h3>Submission errors:</h3><ul>";
    foreach ($errors as $er) echo "<li>" . htmlspecialchars($er) . "</li>";
    echo "</ul><p><a href='form.php'>Go back</a></p>";
    exit;
}

try {
    // Handle file uploads
    foreach (['cnic_front','cnic_back','passport_photo','frc'] as $f) {
        if (!empty($_FILES[$f]['name']) && (is_array($_FILES[$f]['name']) ? $_FILES[$f]['error'][0] === UPLOAD_ERR_OK : $_FILES[$f]['error'] === UPLOAD_ERR_OK)) {
            $moved = move_single_file($f, $uploadDirBase, $f . '_');
            if ($moved) $data[$f] = $moved;
        } elseif (!empty($_POST[$f.'_old'])) {
            $data[$f] = $_POST[$f.'_old'];
        } else {
            $data[$f] = null;
        }
    }

    // Save or update employee record
    if ($employee_id) {
        $setStr = implode(',', array_map(fn($k) => "$k=:$k", array_keys($data)));
        $stmt = $pdo->prepare("UPDATE employees SET $setStr WHERE id=:id AND user_id=:user_id");
        $data['id'] = $employee_id;
        $data['user_id'] = $user_id;
        $stmt->execute($data);
    } else {
        $keys = implode(',', array_keys($data));
        $vals = ':' . implode(',:', array_keys($data));
        $stmt = $pdo->prepare("INSERT INTO employees ($keys) VALUES ($vals)");
        $stmt->execute($data);
        $employee_id = $pdo->lastInsertId();
    }

    // Handle qualifications
    $pdo->prepare("DELETE FROM employee_qualifications WHERE employee_id=?")->execute([$employee_id]);

    $qualEntries = [];
    if (!empty($_POST['qualification_name'])) {
        foreach ($_POST['qualification_name'] as $i => $name) {
            $name = trim($name);
            if ($name === '') continue;

            $certPath = null;
            if (!empty($_FILES['certificate_file']['name'][$i]) && $_FILES['certificate_file']['error'][$i] === UPLOAD_ERR_OK) {
                $certPath = move_file_array_index('certificate_file', $i, $uploadDirBase, 'cert_');
            } elseif (!empty($_POST['certificate_file_old'][$i])) {
                $certPath = $_POST['certificate_file_old'][$i];
            }

            $stmt = $pdo->prepare("INSERT INTO employee_qualifications (employee_id, qualification_name, certificate_file) VALUES (?, ?, ?)");
            $stmt->execute([$employee_id, $name, $certPath]);

            $qualEntries[] = ['name'=>$name, 'file'=>$certPath];
        }
    }

    // Handle relatives - UPDATED VERSION
   // Handle relatives - UPDATED VERSION
 $pdo->prepare("DELETE FROM relatives WHERE employee_id=?")->execute([$employee_id]);

 $relEntries = [];
 $relation_types = $_POST['relation_type'] ?? [];
 $id_types = $_POST['relative_id_type'] ?? [];
 $employee_nos = $_POST['relative_employee_no'] ?? [];
 $family_nos = $_POST['relative_family_no'] ?? [];
 $names = $_POST['relative_name'] ?? [];
 $nationalities = $_POST['relative_nationality'] ?? [];
 $marital_statuses = $_POST['relative_marital_status'] ?? [];

for ($i = 0; $i < count($relation_types); $i++) {
    $relation = trim($relation_types[$i] ?? '');
    $idType = trim($id_types[$i] ?? 'CNIC');
    $employeeNo = trim($employee_nos[$i] ?? '');
    $familyNo = trim($family_nos[$i] ?? '');
    $name = trim($names[$i] ?? '');
    $firstName = $name; // Using name as first_name for compatibility
    $lastName = ''; // Empty last name for now
    $cnic = preg_replace('/\D/','', $_POST['relative_cnic'][$i] ?? '');
    $dob = $_POST['relative_dob'][$i] ?? null;
    $bloodGroup = $_POST['relative_blood_group'][$i] ?? null;
    $nationality = trim($nationalities[$i] ?? 'Pakistani');
    $maritalStatus = trim($marital_statuses[$i] ?? '');
    $medical = $_POST['availing_medical_elsewhere'][$i] ?? 0;

    if ($name === '' && $cnic === '') continue;

    // Handle file uploads for relatives
    $rf_front = $rf_back = $rf_photo = null;

    // Check for existing files
    if (!empty($_POST['relative_cnic_front_old'][$i])) $rf_front = $_POST['relative_cnic_front_old'][$i];
    if (!empty($_POST['relative_cnic_back_old'][$i])) $rf_back = $_POST['relative_cnic_back_old'][$i];
    if (!empty($_POST['relative_photo_old'][$i])) $rf_photo = $_POST['relative_photo_old'][$i];

    // Handle new file uploads
    if (!empty($_FILES['relative_cnic_front']['name'][$i]) && $_FILES['relative_cnic_front']['error'][$i] === UPLOAD_ERR_OK) {
        $rf_front = move_file_array_index('relative_cnic_front', $i, $uploadDirBase, 'rel_front_');
    }
    if (!empty($_FILES['relative_cnic_back']['name'][$i]) && $_FILES['relative_cnic_back']['error'][$i] === UPLOAD_ERR_OK) {
        $rf_back = move_file_array_index('relative_cnic_back', $i, $uploadDirBase, 'rel_back_');
    }
    if (!empty($_FILES['relative_photo']['name'][$i]) && $_FILES['relative_photo']['error'][$i] === UPLOAD_ERR_OK) {
        $rf_photo = move_file_array_index('relative_photo', $i, $uploadDirBase, 'rel_photo_');
    }

    // Insert into database with all fields
    $stmt = $pdo->prepare("INSERT INTO relatives (employee_id, relation_type, id_type, first_name, last_name, cnic, date_of_birth, blood_group, availing_medical_elsewhere, cnic_front, cnic_back, passport_photo, employee_no, family_no, nationality, marital_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$employee_id, $relation, $idType, $firstName, $lastName, $cnic, $dob, $bloodGroup, $medical, $rf_front, $rf_back, $rf_photo, $employeeNo, $familyNo, $nationality, $maritalStatus]);

    $relEntries[] = [
        'relation'=>$relation, 
        'id_type'=>$idType,
        'employee_no'=>$employeeNo,
        'family_no'=>$familyNo,
        'name'=>$name,
        'first'=>$firstName, 
        'last'=>$lastName, 
        'cnic'=>$cnic, 
        'dob'=>$dob,
        'blood_group'=>$bloodGroup,
        'nationality'=>$nationality,
        'marital_status'=>$maritalStatus,
        'medical'=>$medical, 
        'cnic_front'=>$rf_front, 
        'cnic_back'=>$rf_back, 
        'photo'=>$rf_photo
    ];
}
    // Handle deletion of existing relatives
    if (!empty($_POST['existing_relative_delete'])) {
        foreach ($_POST['existing_relative_delete'] as $delId) {
            $delId = intval($delId);
            $pdo->prepare("DELETE FROM relatives WHERE id = ? AND employee_id = ?")->execute([$delId, $employee_id]);
        }
    }

    // Handle autosave
    if (isset($_POST['autosave']) || (isset($_POST['autosave_mode']) && $_POST['autosave_mode']=='1')) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>true, 'id'=>$employee_id, 'employee_no'=>$employee_no]);
        exit;
    }

    // Handle form submission
    if ($action === 'submit') {
        // Create a copy of the data for submission
        $submittedData = $data;
        unset($submittedData['draft']);

        // Ensure employee_no is included in submitted data
        $submittedData['employee_no'] = $employee_no;

        foreach (['cnic_front','cnic_back','passport_photo','frc'] as $f) {
            $submittedData[$f] = $data[$f] ?? null;
        }

        $keys = implode(',', array_keys($submittedData));
        $vals = ':' . implode(',:', array_keys($submittedData));
        $stmt = $pdo->prepare("INSERT INTO submitted_employees ($keys) VALUES ($vals)");
        $stmt->execute($submittedData);
        $submitted_id = $pdo->lastInsertId();

        // Save qualifications to submitted table
        foreach ($qualEntries as $qe) {
            $stmt = $pdo->prepare("INSERT INTO s_employee_qualifications (employee_id, qualification_name, certificate_file) VALUES (?, ?, ?)");
            $stmt->execute([$submitted_id, $qe['name'], $qe['file']]);
        }

        // Save relatives to submitted table - using correct field names
        foreach ($relEntries as $re) {
            $stmt = $pdo->prepare("INSERT INTO submitted_relatives (employee_id, relation_type, id_type, first_name, last_name, cnic, date_of_birth, blood_group, availing_medical_elsewhere, cnic_front, cnic_back, passport_photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$submitted_id, $re['relation'], $re['id_type'], $re['first'], $re['last'], $re['cnic'], $re['dob'], $re['blood_group'], $re['medical'], $re['cnic_front'], $re['cnic_back'], $re['photo']]);
        }

        // Clean up draft data
        $pdo->prepare("DELETE FROM employee_qualifications WHERE employee_id = ?")->execute([$employee_id]);
        $pdo->prepare("DELETE FROM relatives WHERE employee_id = ?")->execute([$employee_id]);
        $pdo->prepare("DELETE FROM employees WHERE id = ?")->execute([$employee_id]);

        // Return JSON response for AJAX requests
        if (isset($_POST['ajax'])) {
            header('Content-Type: application/json');
            echo json_encode(['success'=>true, 'id'=>$submitted_id, 'employee_no'=>$employee_no, 'redirect'=>"form.php?id=$submitted_id&status=submitted"]);
            exit;
        }

        // Redirect to submitted form view
        header("Location: form.php?id=$submitted_id&status=submitted");
        exit;
    }

    // Return success response for draft saves
    if (isset($_POST['ajax'])) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>true, 'id'=>$employee_id, 'employee_no'=>$employee_no, 'message'=>'Draft saved']);
        exit;
    } else {
        header("Location: form.php?id=$employee_id&status=success");
        exit;
    }

} catch (PDOException $e) {
    // Handle errors
    if (isset($_POST['ajax']) || isset($_POST['autosave'])) {
        header('Content-Type: application/json');
        echo json_encode(['success'=>false, 'error'=>$e->getMessage()]);
        exit;
    }
    echo "Error: " . htmlspecialchars($e->getMessage());
    exit;
}